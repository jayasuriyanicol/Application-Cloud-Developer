import React from "react";

const Saluto = () => {
  return (

    <h1> Benvenuto nel mio primo componente React! </h1>
  )
}

export default Saluto;




/* Per l'avviamento in APP

import CardUtente from "./Esercizi Vite/Esercizi React Agosto /Esercizio 1/Saluto";

function App (){

  return(
  <div>
    <Saluto></Saluto>
  </div>
  )

}

export default App; 

*/
