const piatti =[ 

   {id : 1, nome: "Risotto alla Pescatora", prezzo: 6.50 },
   {id : 2, nome: "Pizza Patate e Salsiccie", prezzo: 5.50},
   {id : 3, nome: "Frittura di Pesce", prezzo: 9.50},
   {id : 4, nome: "Torta al Limone", prezzo: 6.45 }

];

export default piatti;